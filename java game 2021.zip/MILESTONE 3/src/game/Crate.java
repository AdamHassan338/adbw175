package game;

import city.cs.engine.*;
import city.cs.engine.Shape;

import java.awt.*;

public class Crate extends DynamicBody {
    //sets hit box shape and size
    private static final Shape crateShape = new BoxShape(2.5f,2.5f);
    //crate image
    private static final BodyImage image = new BodyImage("data/crate.png", 5f);

    public Crate(World world) {
        //creates body in the world with hitbox
        super(world,crateShape);
        addImage(image);

    }
}
