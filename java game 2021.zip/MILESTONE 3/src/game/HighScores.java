package game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class HighScores {
    private JPanel scoresPanel;
    private JPanel sumbitPanel;
    private JLabel nameLabel;
    private JTextField nameText;
    private JLabel scoreLabel;
    private JLabel scoreValue;
    private JButton saveButton;
    private JButton closeButton;
    private JList<String> scoreList;

    private HighScoreWriter highScoreWriter;
    private HighScoreReader highScoreReader;

    private final String filename = "data/highScores.txt";

    private Game game;

    public HighScores(Game game){
        this.game = game;
        int score = game.getTotalTime();

        scoreValue.setText(Integer.toString(score));
        File scores = new File(filename);
        try{
            scores.createNewFile();
        }catch (IOException ex){
            ex.printStackTrace();
        }

        highScoreReader = new HighScoreReader(filename);
        highScoreWriter = new HighScoreWriter(filename);

        //save button
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    highScoreWriter.writeHighScore(nameText.getText(),score);//method writes name and score to high scores text file
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                System.exit(0);
            }
        });

        //close button
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.deleteSave();
                System.exit(0);
            }
        });

        DefaultListModel<String> model = new DefaultListModel<>();
        try{
            model.addAll(highScoreReader.readScores());
        }catch (IOException ex){
            ex.printStackTrace();
        }
        scoreList.setModel(model);

    }

    public JPanel scoresPanel() {
        return scoresPanel;
    }
}
