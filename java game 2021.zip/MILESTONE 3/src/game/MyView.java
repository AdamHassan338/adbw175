package game;

import city.cs.engine.UserView;
import city.cs.engine.World;

import javax.swing.*;
import java.awt.*;

public class MyView extends UserView{
    private static Image background;
    private Game game;
    private  Graphics2D graphics;

    public MyView(World w,int width,int height,Game game){
        //creates the user view
        super(w,width,height);
        this.game=game;
        //background image
        background= new ImageIcon("data/Background.gif").getImage();


    }
    @Override
    protected void paintBackground(Graphics2D g) {
        this.graphics=g;
        // adds background image
        graphics.drawImage(background, 0, 0, this);
    }
    @Override
    protected void paintForeground(Graphics2D g) {
        //draw health and coins and time on screen
        g.drawString("Health: " + game.getLevel().getPlayer().getHealth(), 10, 20);
        g.drawString("Coins: " + game.getLevel().getPlayer().getCoins(), 10, 10);
        g.drawString("Time: " + game.getLevel().getTime(), 100, 10);


    }





}