package game;

import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;


/**
 * Player Class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */

public class Player extends Walker{

    private int health; //player health

    private String Direction; //stores direction player is facing

    private int coins; //stores the number of coins player has

    private int kills; //stores the number of zombies player has killed in a level


    private static SoundClip pickup; //pickup sound

    private static SoundClip teleport; // teleport sound

    private static SoundClip hit; //player got hit sound

    //exception for if the Pickup.wav is not found
    static {
        try{
            pickup = new SoundClip("data/Pickup.wav");//sets pickup sound file
            pickup.setVolume(0.05);
        }catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
            e.printStackTrace();
        }
    }
    //exception for if the teleport.wav is not found or unsupported file type
    static {
        try{
            teleport = new SoundClip("data/teleport.wav");//sets teleport sound file
        }catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
            e.printStackTrace();
        }
    }
    //exception for if the hit.wav is not found or unsupported file type
    static {
        try{
            hit = new SoundClip("data/hit.wav");//sets hit sound file
            hit.setVolume(0.08);
        }catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
            e.printStackTrace();
        }
    }

    //stores player size
    private float size = 5f;


    //creates BodyImage from player image  with size
    private BodyImage image= new BodyImage("data/player-right.png", size);

    //player hit box
    private static final Shape playerShape = new PolygonShape(-0.79f,-1.9f,
            0.8f,-1.92f, 0.65f,1.87f,
            0.11f,2.39f, -0.67f,1.6f,
            -0.82f,-1.82f);


    /**
     * Player constructor
     *
     * initialises attributes of player to default values
     * @param world the level or world the player will be placed in
     */
    public Player(World world) {
        //places player in world with hit-box as a walker
        super(world, playerShape);
        addImage(image);

        //player starting attribute values
        coins=0;
        kills=0;
        health = 100;
    }


    /**
     * getter for player direction
     * @return Returns Direction player is currently facing as string(right or left).
     */
    //gets direction player is facing
    public String getDirection() {
        return Direction;
    }


    /**
     * Setter for player direction
     * @param  direction String should be either "left" or "right".
     *
     */
    //setter for direction
    public void setDirection(String direction) {
        Direction = direction;
    }

    /**
     * getter for player health
     * @return returns player health value.
     */
    //getter for health
    public int getHealth() {
        return health;
    }

    /**
     * Setter for player health.
     * used for when loading from save
     * @param  health int value.
     */
    //setter for health
    public void setHealth(int health) {
        this.health = health;
    }

    /**
     * Setter for player model.
     * @param  image a BodyImage for the player.
     */
    //sets image of player
    public void setImage(BodyImage image) {
        this.image = image;
    }

    /**
     * Getter for player coins.
     * @return Returns number of coins player has.
     */
    //getter for coins
    public int getCoins() {
        return coins;
    }

    /**
     * setter for player coins.
     * used for when loading from a save
     * @param coins new value for player coins
     *
     */
    //setter for coins
    public void setCoins(int coins) {
        this.coins = coins;
    }


    /**
     * getter for player kills
     * use for saving game state
     * @return number of zombies killed by player
     */
    //getter for kills
    public int getKills() {
        return kills;
    }


    /**
     * Setter for player kills
     * used for restoring game state, ensuring you can save multiple times
     * @param kills the new number of zombies the player has killed
     */
    //setter for kills
    public void setKills(int kills) {
        this.kills = kills;
    }


    /**
     * Incrementer coins
     * add 1 to player coins
     */
    //increments coin total
    public void addCoin(){
        this.coins++;
    }

    /**
     * plays pickup sound
     */
    public void playPickUp(){
        pickup.play();
    }
    /**
     * plays teleport sound
     */
    public void playTeleport(){
        teleport.play();
    }
    /**
     * plays hit sound
     */
    public void playHit(){
        hit.play();
    }



    /**
     * Getter for player size
     * @return size of player model
     */
    //player size getter
    public float getSize() {
        return size;
    }


}
