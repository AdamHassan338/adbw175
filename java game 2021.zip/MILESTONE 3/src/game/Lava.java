package game;

import city.cs.engine.*;
import city.cs.engine.Shape;

import java.awt.*;
/**
 * Lava class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */
public class Lava extends StaticBody {
    //creates hit-box
    private static final Shape lavaShape = new BoxShape(1280f, 0.5f);


    /**
     * Lava constructor
     * places lava in world and sets it image to red
     * @param world world the Lava will be placed in
     */
    public Lava(World world){
        //creates body in the world with hitbox
        super(world, lavaShape);
        this.setFillColor(Color.red);

    }
}
