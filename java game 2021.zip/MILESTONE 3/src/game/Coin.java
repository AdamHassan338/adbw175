package game;

import city.cs.engine.*;

/**
 * Coin class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */
public class Coin extends StaticBody {

    //sets hit box shape and size
    private static final Shape coinShape = new PolygonShape(-0.29f,1.78f, 0.21f,1.78f, 1.33f,0.4f, 1.47f,-1.16f, 0.0f,-2.16f, -1.58f,-0.73f, -0.39f,1.76f);
    //image of the coin
    private BodyImage image= new BodyImage("data/Coin.gif", 2f);

    /**
     * Coin constructor
     * places coin in world and adds image to the coin
     * @param world world the coin will be placed in
     */
    public Coin(World world){
        //creates body in the world with hitbox
        super(world, coinShape);
        addImage(image);

    }
}
