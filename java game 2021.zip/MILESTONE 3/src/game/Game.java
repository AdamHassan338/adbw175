package game;

import javax.swing.*;
import java.awt.*;
import java.io.File;


public class Game {

    /* the world */
    private GameLevel level;
    private PlayerController controller;
    private  JFrame frame;
    private Timer timer;
    private int level1Time;
    private int level2Time;
    private int level3Time;
    private int totalTime;
    private boolean skipped;


    /** A graphical display of the world (a specialised JPanel). */
    private MyView view;

    /** Initialise a new Demo. */
    public Game() {

        // initialize level to Level1
        level = new Level1(this);


        // make a view
        view = new MyView(level, 1280, 720,this);//make this smaller



        //player movement controller object
        controller = new PlayerController(level.getPlayer());
        view.addKeyListener(controller);

        // display the view in a frame
        final JFrame frame = new JFrame("Encapsulation Demo");
        view.setFocusable(true);
        frame.add(view,BorderLayout.CENTER);


        //add the options menue to left side
        Options options = new Options(this);
        frame.add(options.getMainPanel(), BorderLayout.EAST);





        // quit the application when the game window is closed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);


        // don't let the game window be resized
        frame.setResizable(false);
        // size the game window to fit the world view
        frame.pack();
        // make the window visible
        frame.setVisible(true);

        // debug viewer
        // JFrame debugView = new DebugViewer(world, 500, 500);

        // starts game
        level.start();

        /*timer = new Timer(1000, new TimeHandler());
        timer.setInitialDelay(100);
        timer.start();*/


    }

    /* runs game */
    public static void main(String[] args) {
        new Game();
    }

    //method loads next level and exits when final level
    public void goToNextLevel(){
        if (level instanceof Level1){
            level.stopMusic();
            level.stopTimer();
            level1Time = level.getTime();
            level.stop();
            level = new Level2(this);//switches level to level2
            //level now refer to the new level
            view.setWorld(level);
            controller.updatePlayer(level.getPlayer());
            view.addKeyListener(controller);
            level.start();
        }
        else if (level instanceof Level2){
            level.stopMusic();
            level.stopTimer();
            level2Time = level.getTime();
            level.stop();
            level = new Level3(this);//switches level to level3
            //level now refer to the new level
            view.setWorld(level);
            controller.updatePlayer(level.getPlayer());
            view.addKeyListener(controller);
            level.start();
        }
        else {
            level.stopTimer();
            level3Time = level.getTime();
            totalTime = level1Time+level2Time+level3Time; // totals up time
            JDialog scoresDialog = new JDialog(frame ,true);


            /*there are two versions of the high scores screen to ensure that if you skipped
             then you cant submit your time to the list but you can still see others times*/

            if(!skipped){

                HighScores highScores = new HighScores(this);
                scoresDialog.getContentPane().add(highScores.scoresPanel());
                scoresDialog.pack();
                scoresDialog.setVisible(true);

                System.out.println("Well done! Game complete.");
                System.out.println("total time: " +totalTime);
            }
            else {
                HighScoresNoInput highScores = new HighScoresNoInput(this);
                scoresDialog.getContentPane().add(highScores.scoresPanel());
                scoresDialog.pack();
                scoresDialog.setVisible(true);

                System.out.println("Well done! Game complete.");

            }
            deleteSave();//calls method to delete save file
            System.exit(0);
        }
    }

    //Level getter
    public GameLevel getLevel(){
        return level;
    }
    //total time getter
    public int getTotalTime(){
        return totalTime;
    }

    //returns the view
    public MyView getView(){
        return view;
    }

    //sets game frame in focus
    public void setGameFocus(){
        view.requestFocus();
    }

    //skipped setter
    public void setSkipped(boolean x){
        skipped = x;
    }

    // reload current level by setting level variable to a new object of the same class
    public void reloadLevel(){
        level.stopMusic();
        level.stop();
        if (level instanceof Level1){
            level = new Level1(this);
        }
        if (level instanceof Level2){
            level = new Level2(this);
        }
        if (level instanceof Level3){
            level = new Level3(this);
        }
        //level now refer to the new level
        view.setWorld(level);
        controller.updatePlayer(level.getPlayer());
        view.addKeyListener(controller);
        level.start();
    }
    //restart whole game
    public void restart(){
        level.stopMusic();
        level.stop();
        level = new Level1(this);
        //level now refer to the new level
        view.setWorld(level);
        controller.updatePlayer(level.getPlayer());
        view.addKeyListener(controller);
        level.start();
    }

    //switch level to specific level
    public void goToLevel(GameLevel level){
        this.level.stopMusic();
        this.level.stop();
        this.level = level;//change level value

        view.setWorld(this.level);
        controller.updatePlayer(this.level.getPlayer());//update player controller so can move
        view.addKeyListener(controller);
        this.level.start();
    }

    public void deleteSave(){
        File gameSave = new File("data/save.txt");
        gameSave.delete();//deletes save file
    }
}
