package game;

import city.cs.engine.SoundClip;
import game.GameWorld;
import org.jbox2d.common.Vec2;

/**
 * abstract Game Level class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */
public abstract class GameLevel extends GameWorld {

    private Player player;
    private Zombie zombie;
    private Game game;

    /**
     * Game Level constructor
     * @param game the game object
     */
    public GameLevel(Game game) {
        this.game=game;
            //player = new Player(this);
            //zombie = new Zombie(this,player);
            //ZombieDamage zombieDamage = new ZombieDamage(zombie);
            //zombie.addCollisionListener(zombieDamage);
            //PlayerCollision playerCollision = new PlayerCollision(player,this);
            //player.addCollisionListener(playerCollision);


        }
    //player getter

    /**
     * player getter
     * @return the player in the level
     */
    public Player getPlayer() {
        return player;
    }
    //zombie position getter

    /**
     * gets the position of a zombie
     * @param zombie the zombie you want
     * @return the position as Vec2
     */
    public abstract Vec2 getZombiePosition(Zombie zombie);

    //zombie getters

    /**
     * zombie1 getter
     * @return zombie object
     */
    public abstract Zombie getZombie1();
    /**
     * zombie2 getter
     * @return zombie object
     */
    public abstract Zombie getZombie2();

    //game getter

    /**
     * game getter
     * @return the game
     */
    public Game getGame(){
        return game;
    }

    //calls method to restart game from level1

    /**Restarts game
     * calls method to restart game from level1
     */
    public void restartGame(){
        game.restart();
    }

    /**
     * checks if level finish requirements are met
     * all coins are collected
     * @return true if all coins collected false if not
     */
    public abstract boolean isComplete();

    /**
     *  getter for current time
     * @return level time in seconds
     */
    public abstract int getTime();

    /**
     * sets time for level
     * used when loading from a save
     * @param levelTime time to set current level time to
     */
    public abstract void setTime(int levelTime);

    /**
     * stops the level timer counting
     * used when switching levels
     */
    public abstract void stopTimer();

    /**
     * gets the level name
     * @return the current level name String
     */
    public abstract String getLevelName();

    /**
     *destroys n number of coins from the level
     * used when restoring game state
     * @param n number of cons to destroy
     */
    public abstract void destroyCoins(int n);

    /**
     *destroys n number of zombies from the level
     * used when restoring game state for a save
     * @param n number of zombies to destroy
     */
    public abstract void destroyZombies(int n);

    /**
     * getter for the crate position
     * used when saving the position
     * @return the position of the crate in Vec2
     */
    public abstract Vec2 getCrate1Pos();

    /**
     * sets the crate position for the crate in level 3
     * used when loading from a save
     * @param pos the position to place crate in Vec2
     */
    public abstract void setCrate1Pos(Vec2 pos);
}

