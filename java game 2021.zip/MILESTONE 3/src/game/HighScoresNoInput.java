package game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class HighScoresNoInput {
    private JPanel scoresPanel;
    private JPanel sumbitPanel;
    private JButton closeButton;
    private JList<String> scoreList;

    private HighScoreWriter highScoreWriter;
    private HighScoreReader highScoreReader;

    private final String filename = "data/highScores.txt";

    private Game game;

    public HighScoresNoInput(Game game){
        this.game = game;
        File scores = new File(filename);
        try{
            scores.createNewFile();
        }catch (IOException ex){
            ex.printStackTrace();
        }

        highScoreReader = new HighScoreReader(filename);
        highScoreWriter = new HighScoreWriter(filename);



        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.deleteSave();
                System.exit(0);
            }
        });

        DefaultListModel<String> model = new DefaultListModel<>();
        try{
            model.addAll(highScoreReader.readScores());
        }catch (IOException ex){
            ex.printStackTrace();
        }
        scoreList.setModel(model);

    }

    public JPanel scoresPanel() {
        return scoresPanel;
    }
}
