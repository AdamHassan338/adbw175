package game;

import org.jbox2d.common.Vec2;

import java.io.*;

/**
 * Saving and Loading game class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */
public class GameSaveLoad {
    /**
     * Save game method
     * saved to file in this order:
     *             1) current level
     *             2) player x cord
     *             3) player y cord
     *             4) player health value
     *             5) player coins
     *             6) time spent in current level
     *             7) zombies killed
     *             8) zombie 1 x cord
     *             9) zombie 1 y cord
     *             10) zombie 2 x cord
     *             11) zombie 2 y cord
     *             12) crate x cord
     *             13) crate y cord
     * @param level current level
     * @param file  director and name of file you will save to
     * @throws IOException if file cannot be opened
     *
     */
    public static void save(GameLevel level,String file) throws IOException {

        FileWriter writer = null;
        try {
            writer = new FileWriter(file, false);//opens file as overwrite
            //level 3 save has to be different because it contains a crate and need to save position of that
            /*
            saved to file in this order:
            1) current level
            2) player x cord
            3) player y cord
            4) player health value
            5) player coins
            6) time spent in current level
            7) zombies killed
            8) zombie 1 x cord
            9) zombie 1 y cord
            10) zombie 2 x cord
            11) zombie 2 y cord
            12) crate x cord
            13) crate y cord
            */
            if(level.getLevelName().equals("level3")){
                writer.write(level.getLevelName() + "," + level.getPlayer().getPosition().x + "," + level.getPlayer().getPosition().y + " ," + level.getPlayer().getHealth() +"," + level.getPlayer().getCoins() + ","+level.getTime() + "," + level.getPlayer().getKills() +","+ level.getZombie1().getPosition().x +","+ level.getZombie1().getPosition().y+ ","+ level.getZombie2().getPosition().x +","+ level.getZombie2().getPosition().y +","+ level.getCrate1Pos().x +","+ level.getCrate1Pos().y + "\n");
            }
            else{
                writer.write(level.getLevelName() + "," + level.getPlayer().getPosition().x + "," + level.getPlayer().getPosition().y + " ," + level.getPlayer().getHealth() +"," + level.getPlayer().getCoins() + ","+level.getTime() + "," + level.getPlayer().getKills() +","+ level.getZombie1().getPosition().x +","+ level.getZombie1().getPosition().y+ ","+ level.getZombie2().getPosition().x +","+ level.getZombie2().getPosition().y+"\n");
            }
        } finally {
            if (writer != null) {
                writer.close();
            }
        }

    }

    /**
     * Game Load level
     * @param game the game object that stores the view you want to add the new level to
     * @param file The file you will be loading from
     * @return the new loaded level object
     * @throws IOException if file cannot me opened
     */
    public static GameLevel load(Game game,String file) throws IOException {
        FileReader fr = null;
        BufferedReader reader = null;
        try {
            System.out.println("Reading " + file + " ...");
            fr = new FileReader(file);//opens file as file reader
            reader = new BufferedReader(fr);
            String line = reader.readLine();

            // file is assumed to contain one name, score pair per line
            String[] tokens = line.split(",");//splits string in the line at the commas and put those sub strings into and array
            String levelName = tokens[0];
            float playerPosX = Float.parseFloat(tokens[1]);
            float playerPosY = Float.parseFloat(tokens[2]);
            Vec2 playerPos = new Vec2(playerPosX,playerPosY);// combines x and y cords into Vec2

            int playerHealth = Integer.parseInt(tokens[3]);
            int playerCoins = Integer.parseInt(tokens[4]);
            int levelTime = Integer.parseInt(tokens[5]);
            int kills = Integer.parseInt(tokens[6]);

            float zombie1PosX = Float.parseFloat(tokens[7]);
            float zombie1PosY = Float.parseFloat(tokens[8]);

            float zombie2PosX = Float.parseFloat(tokens[9]);
            float zombie2PosY = Float.parseFloat(tokens[10]);

            GameLevel level = null;


            // sets game level here
            if(levelName.equals("level1")){
                level = new Level1(game);


            }
            else if(levelName.equals("level2")){
                level = new Level2(game);

            }
            else if(levelName.equals("level3")){
                level = new Level3(game);
                level.setCrate1Pos(new Vec2(Float.parseFloat(tokens[11]),Float.parseFloat(tokens[12])));

            }
            else{
                System.out.println("empty save: no level");
            }
            //updates the state of the game level here
            level.getPlayer().setHealth(playerHealth);
            level.destroyCoins(playerCoins);
            level.getPlayer().setCoins(playerCoins);
            level.getPlayer().setKills(kills);
            level.getPlayer().setPosition(playerPos);
            level.getZombie1().setPosition(new Vec2(zombie1PosX,zombie1PosY));
            level.getZombie2().setPosition(new Vec2(zombie2PosX,zombie2PosY));
            level.destroyZombies(kills);
            level.setTime(levelTime);

            return level;//returns the level in the state it was when saved

        } finally {
            if (reader != null) {
                reader.close();//close file
            }
            if (fr != null) {
                fr.close();//close file
            }
        }
    }
}
