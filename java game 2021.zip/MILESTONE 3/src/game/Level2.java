package game;


import city.cs.engine.Body;
import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Level2  extends GameLevel implements ActionListener {
    private final Player player;
    private Zombie zombie1;
    private Zombie zombie2;
    private Coin coin1;
    private Coin coin2;
    private Coin coin3;
    private Coin coin4;


    private int time;
    private Timer timer;

    public Level2(Game game) {
        super(game);

        //timer

        timer = new Timer(1000,this);
        timer.start();
        time=0;

        // make the ground
        Shape groundShape = new BoxShape(1280f, 0.5f);
        Body ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, -12f));



        // -----------------------------------CHARACTERS-----------------------------------

        //add player
        player = new Player(this);
        player.setPosition(new Vec2(-31, 14));
        PlayerCollision playercollision = new PlayerCollision(player,this);
        player.addCollisionListener(playercollision);

        //add zombies
        zombie1 = new Zombie(this,player);
        zombie1.setPosition(new Vec2(12,13));
        ZombieDamage zombieDamage1 = new ZombieDamage(zombie1);
        zombie1.addCollisionListener(zombieDamage1);

        zombie2 = new Zombie(this,player);
        zombie2.setPosition(new Vec2(-14,-1));
        ZombieDamage zombieDamage2 = new ZombieDamage(zombie2);
        zombie2.addCollisionListener(zombieDamage2);



        // --------------------------------WALLS AND PLATFORMS--------------------------------


        //platforms

        Shape platShapeLong = new BoxShape(15f,0.5f);
        Shape platShapeSmall= new BoxShape(6f,0.5f);
        Shape platShapeNormal = new BoxShape(13f,0.5f);

        //level 1
        Body platform1= new StaticBody(this,platShapeLong);
        platform1.setPosition(new Vec2(-18,10));
        Body platform2= new StaticBody(this,platShapeLong);
        platform2.setPosition(new Vec2(18,10));

        //level2
        Body platform3= new StaticBody(this,platShapeSmall);
        platform3.setPosition(new Vec2(-0.5f,4));

        //leve3
        Body platform4= new StaticBody(this,platShapeLong);
        platform4.setPosition(new Vec2(20,0));
        Body platform5= new StaticBody(this,platShapeNormal);
        platform5.setPosition(new Vec2(-10,-4));






        // --------------------------------OBJECTS--------------------------------
        coin1 = new Coin(this);
        coin2 = new Coin(this);
        coin3 = new Coin(this);
        coin4 = new Coin(this);
        coin1.setPosition(new Vec2(-18,11.5f));
        coin2.setPosition(new Vec2(18,11.5f));
        coin3.setPosition(new Vec2(20,1.5f));
        coin4.setPosition(new Vec2(-10,-2.5f));


        Portal portal = new Portal(this);
        portal.setPosition(new Vec2(20,-9.1f));



    }
    //player getter
    public Player getPlayer() {
        return player;
    }

    @Override
    public Vec2 getZombiePosition(Zombie zombie) {
        return zombie.getPosition();
    }

    @Override
    public Zombie getZombie1() {
        return zombie1;
    }

    @Override
    public Zombie getZombie2() {
        return zombie2;
    }


    //sets condition for being able to progress to next level
    @Override
    public boolean isComplete() {
        if (getPlayer().getCoins() == 4)
            return true;
        else return false;
    }

    //action listener for timer
    @Override
    public void actionPerformed(ActionEvent e){
        time++;
    }

    public int getTime(){
        return time;
    }

    public void setTime(int levelTime){
        this.time = levelTime;
    }

    public void stopTimer(){
        timer.stop();
    }

    @Override
    public String getLevelName() {
        return "level2";
    }

    public void destroyCoins(int n){
        switch (n) {
            case 1:
                coin1.destroy();
                break;
            case 2:
                coin1.destroy();
                coin2.destroy();
                break;
            case 3:
                coin1.destroy();
                coin2.destroy();
                coin3.destroy();
                break;
            case 4:
                coin1.destroy();
                coin2.destroy();
                coin3.destroy();
                coin4.destroy();
            default:
        }
    }

    @Override
    public void destroyZombies(int n) {
        switch (n) {
            case 1:
                zombie1.destroy();
                break;
            case 2:
                zombie1.destroy();
                zombie2.destroy();
                break;
            default:
        }
    }

    @Override
    public Vec2 getCrate1Pos() {
        return null;
    }

    @Override
    public void setCrate1Pos(Vec2 pos) {

    }
}