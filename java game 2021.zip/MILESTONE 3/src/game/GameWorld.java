
package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;


public class GameWorld extends World {


    private SoundClip gameMusic;
    //base volume is max volume
    private double baseVolume = 0.1;
    private static double musicVolume = 0.05;
    public GameWorld() {
        super();

        //--------------------------------------BACKGROUND MUSIC----------------------------

        //exception for if the theme1.wav is not found
        try{

            //theme music file
            gameMusic = new SoundClip("data/theme1.wav");
            gameMusic.setVolume(musicVolume);
            gameMusic.loop(); // continuously loop audio

        } catch (LineUnavailableException|IOException|UnsupportedAudioFileException e) {
            e.printStackTrace();
        }







    }
    //setter for music volume, volume always a percentage of base volume
    public void setGameMusicVolume(double volume){
        if(volume>0) {
            musicVolume = baseVolume*(volume/100);
            gameMusic.setVolume(musicVolume);
        }
    }
    //stops game music
    public void stopMusic(){
        gameMusic.stop();
    }

    //setter for game music
    public void setGameMusic(SoundClip sound){
        gameMusic=sound;
    }



}
