package game;


import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;



public class PlayerCollision implements CollisionListener {
    private final Player player;
    private GameLevel level;
    public PlayerCollision(Player player,GameLevel level){
        this.player= player;
        this.level=level;

    }

    @Override
    public void collide(CollisionEvent collisionEvent){

        //taking damage
        if(collisionEvent.getOtherBody() instanceof Zombie && player.getGravityScale() == 1){
            //System.out.println("player hit by zombie");
            //adds knock back to player
            if(player.getDirection().equals("Right")) {
                player.startWalking(-10);//knocks back player
            }
            else{
                if(player.getDirection().equals("Left")){
                    player.startWalking(10);//knocks back player
                }
            }
            //player takes damage
            player.setHealth(player.getHealth()-20);
            player.playHit();
            //System.out.println("HEALTH: "+player.getHealth());
        }

        //pickup coin
        if(collisionEvent.getOtherBody() instanceof Coin){
            player.addCoin();
            player.playPickUp();
            collisionEvent.getOtherBody().destroy();
            //System.out.println("coin picked up, total coins: " +player.getCoins());
        }
        //portal
        if(collisionEvent.getOtherBody() instanceof Portal && level.isComplete()){
            level.getGame().goToNextLevel();
            player.playTeleport();

        }
        //lava collition
        if(collisionEvent.getOtherBody() instanceof Lava){
            player.setHealth(0);

        }

        //checks if health is below zero then kills the player if so
        if(player.getHealth()<=0){
            player.destroy();
            level.restartGame();
            System.out.println("player died");
        }





    }



}
