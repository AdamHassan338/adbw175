package game;

import city.cs.engine.Body;
import city.cs.engine.BodyImage;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
/**
 * Player movement class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */
public class PlayerController implements KeyListener {
    private static final float WALKING_SPEED = 4;

    private Player player;
    private String Direction;

    /**
     * Player contoler constructor
     * @param p the player that will be controlled
     */
    public PlayerController(Player p){
        this.player = p;
    }


    /**
     * checks which key is pressed and moves the character if its a movement key
     * also changes the player image if moveing left or right
     * @param e key pressed
     */
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        //movement left
        if (code == KeyEvent.VK_A) {
            player.addImage(new BodyImage("data/player-left.png", player.getSize()));//changes player image to match movement direction
            player.startWalking(-WALKING_SPEED);
            player.setDirection("Left");//keeps track of direction player is facing
        } else if (code == KeyEvent.VK_D) {
            //movement right
            player.addImage(new BodyImage("data/player-right.png", player.getSize()));//changes player image to match movement direction
            player.startWalking(WALKING_SPEED);
            player.setDirection("Right");//keeps track of direction player is facing
        }
        //jumping
        else if(code == KeyEvent.VK_W){
            player.jump(12.0f);
        }
        //start falling
        else if (code == KeyEvent.VK_S){
            //only allows player gravity to increase if they are moving vertically
            if(player.getLinearVelocity().y>0) {
                player.setGravityScale(10);//make player fall faster
            }
        }
    }

    /**
     * stops player movement when the movement key is released
     * @param e the key released
     */
    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();

        //stops movement left
        if (code == KeyEvent.VK_A) {
            player.stopWalking();

        //stops movement right
        } else if (code == KeyEvent.VK_D) {
            player.stopWalking();
        }
        //makes player fall
        else if (code == KeyEvent.VK_S){
            player.setGravityScale(1.0f);// resets gravity
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    /**
     * updates the player being contrlled
     * used when new level is loaded
     * @param player new player object
     */
    public void updatePlayer(Player player){
        this.player = player;
    }//update player for when level is changed to the new player

}
