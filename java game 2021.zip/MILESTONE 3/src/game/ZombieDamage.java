package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class ZombieDamage implements CollisionListener {

    private Zombie zombie;
    public ZombieDamage(Zombie zombie){
        this.zombie=zombie;
    }

    @Override
    public void collide(CollisionEvent collisionEvent){

        if(collisionEvent.getOtherBody() == zombie.getPlayer()){

            if(zombie.getPlayer().getGravityScale() == 10){
                zombie.setHealth(zombie.getHealth()-20);
            }

            //gets rid of zombie if health is zero
            if(zombie.getHealth()<=0){
                zombie.crushZombie();
                zombie.getPlayer().setKills(zombie.getPlayer().getKills()+1);//increment player kills
            }



        }

    }
}
