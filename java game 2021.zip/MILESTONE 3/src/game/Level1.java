package game;


import city.cs.engine.Body;
import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class Level1  extends GameLevel implements ActionListener {
    private final Player player;
    private final Zombie zombie;
    private final Zombie zombie2;
    private Coin coin1;
    private Coin coin2;
    private Coin coin3;
    private Coin coin4;

    private int time;
    private Timer timer;
    private final Image image= new ImageIcon("data/Background.gif").getImage();


    public Level1(Game game) {
        super(game);



        //timer

        timer = new Timer(1000,this);
        timer.start();
        time=0;

        // make the ground
        Shape groundShape = new BoxShape(1280f, 0.5f);
        Body ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, -12f));



        // -----------------------------------CHARACTERS-----------------------------------

        //add player
        player = new Player(this);
        player.setPosition(new Vec2(-31, -10));
        PlayerCollision playercollision = new PlayerCollision(player,this);
        player.addCollisionListener(playercollision);

        //add zombies
        zombie = new Zombie(this,player);
        zombie.setPosition(new Vec2(-12,-5.5f));
        ZombieDamage zombieDamage = new ZombieDamage(zombie);
        zombie.addCollisionListener(zombieDamage);


        zombie2 = new Zombie(this,player);

        zombie2.setPosition(new Vec2(-2,-10));
        ZombieDamage zombieDamage2 = new ZombieDamage(zombie2);
        zombie2.addCollisionListener(zombieDamage2);




        // --------------------------------WALLS AND PLATFORMS--------------------------------


        //platforms

        Shape platShapeNormal = new BoxShape(3.5f,0.5f);
        Shape platShapeSmall = new BoxShape(2.5f,0.5f);


        Body platform1= new StaticBody(this,platShapeNormal);
        platform1.setPosition(new Vec2(-26,-6));

        Body platform2 = new StaticBody(this,platShapeSmall);
        platform2.setPosition(new Vec2(-18,-3));

        Body platform3 = new StaticBody(this,platShapeNormal);
        platform3.setPosition(new Vec2(-11,-6.5f));

        Body platform4 = new StaticBody(this,platShapeNormal);
        platform4.setPosition(new Vec2(-6.2f,3f));




        // --------------------------------OBJECTS--------------------------------
        coin1 = new Coin(this);
        coin2 = new Coin(this);
        coin3 = new Coin(this);
        coin4 = new Coin(this);
        coin1.setPosition(new Vec2(-26,-4.5f));
        coin2.setPosition(new Vec2(-18,-1.5f));
        coin3.setPosition(new Vec2(-9,-5));
        coin4.setPosition(new Vec2(-6.2f,4.5f));

        Portal portal = new Portal(this);
        portal.setPosition(new Vec2(20,-9.1f));

    }
    //getter for player
    public Player getPlayer() {
        return player;
    }

    @Override
    public Vec2 getZombiePosition(Zombie zombie) {
        return zombie.getPosition();
    }

    @Override
    public Zombie getZombie1() {
        return zombie;
    }

    @Override
    public Zombie getZombie2() {
        return zombie2;
    }


    //sets condition for being able to progress to next level
    @Override
    public boolean isComplete() {
        if (getPlayer().getCoins() == 4)
            return true;
        else return false;
    }

    //getter for player image
    private Image getImage(){
        return image;
    }

    //action listener for timer
    @Override
    public void actionPerformed(ActionEvent e){
        time++;
    }

    public int getTime(){
        return time;
    }
    public void setTime(int levelTime){
        this.time = levelTime;
    }

    public void stopTimer(){
        timer.stop();
    }

    @Override
    public String getLevelName() {
        return "level1";
    }

    public void destroyCoins(int n){
        switch (n) {
            case 1:
                coin1.destroy();
                break;
            case 2:
                coin1.destroy();
                coin2.destroy();
                break;
            case 3:
                coin1.destroy();
                coin2.destroy();
                coin3.destroy();
                break;
            case 4:
                coin1.destroy();
                coin2.destroy();
                coin3.destroy();
                coin4.destroy();

                break;
            default:
        }
    }

    @Override
    public void destroyZombies(int n) {
        switch (n) {
            case 1:

                zombie.destroy();
                break;
            case 2:
                zombie.destroy();
                zombie2.destroy();
                break;
            default:
        }



    }

    @Override
    public Vec2 getCrate1Pos() {
        return null;
    }

    @Override
    public void setCrate1Pos(Vec2 pos) {

    }

    /*    public void save(String file) throws IOException {

        FileWriter writer = null;
        try {
            writer = new FileWriter(file, false);
            writer.write(this.getLevelName() + "," + this.getPlayer().getPosition() +"," + this.getPlayer().getCoins() +"," + this.getPlayer().getHealth() +"," +  "\n");
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }
*/


}


