package game;

import city.cs.engine.*;
/**
 * Portal class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */
public class Portal extends StaticBody {

    //sets hit box shape and size
    private static final Shape portalShape = new PolygonShape(-0.62f,-2.37f,
            0.61f,-2.34f,
            1.03f,-0.63f, 1.02f,0.64f, -0.06f,2.52f, -1.03f,0.66f, -1.03f,-0.61f, -0.68f,-2.33f);
    //image of the coin
    private BodyImage image= new BodyImage("data/Portal.gif", 5f);
    /**
     * Portal constructor
     * places portal in world and sets it image to red
     * @param world world the Portal will be placed in
     */
    public Portal(World world){
        //places portal in world with hit-box as static body
        super(world, portalShape);
        addImage(image);

    }
}
