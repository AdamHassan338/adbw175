package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
/**
 * Zombie Class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */

public class Zombie extends Walker implements StepListener{

    private int health;
    //player is attribute of zombie so ZombieDamage can access player methods
    private final Player player;
    private static SoundClip crush;
    static {
        try{
            crush = new SoundClip("data/flesh_squishy_impact_hard2.wav");
            crush.setVolume(0.03);
        }catch (LineUnavailableException | IOException | UnsupportedAudioFileException e) {
            e.printStackTrace();
        }
    }

    //zombie hit box
    private static final Shape zombieShape = new PolygonShape(1.18f,0.58f, 1.21f,-2.46f, -0.66f,-2.41f, -1.46f,-0.76f, -0.18f,1.82f, 1.16f,0.66f);

    //zombie image
    private static final BodyImage image= new BodyImage("data/zombie.png", 5f);

    private enum State {
        MOVE_LEFT, MOVE_RIGHT, STAND_STILL
    }
    public static final Vec2 RANGE = new Vec2(10,5) ;
    private State state;
    private Vec2 velocityRight = new Vec2(2,0);
    private Vec2 velocityLeft = new Vec2(-2,0);

    /**
     * Zombie constructor
     *
     * initialises attributes of zombie to default values
     * @param world the level or world the zombie will be placed in
     * @param player the player object the zombie will be interacting with
     */
    public Zombie(World world,Player player) {
        super(world, zombieShape);
        this.player = player;
        addImage(image);
        //zombie start health
        health = 20;
        state = State.STAND_STILL;
        getWorld().addStepListener(this);
    }
    //player getter

    /**
     * Player getter
     * @return the player the zombie is interacting with
     */
    public Player getPlayer() {
        return player;
    }
    //health getter

    /**
     * Zombie Health getter
     * @return returns current health of zombie
     */
    public int getHealth() {
        return health;
    }
    //setter health

    /**
     * Zombie Health Setter
     * @param health current zombie health
     */
    public void setHealth(int health) {
        this.health = health;
    }

    /**
     * kills the zombie
     */
    public void crushZombie(){
        crush.play();
        destroy();
    }

    /**
     * checks if the player is with in the range left of the zombie
     * @return true if within range false if out of range
     */
    public boolean inRangeLeft() {
        Body a = player;
        //calculate distance between player and zombie
        float gapX = getPosition().x - a.getPosition().x;
        float gapY = getPosition().y - a.getPosition().y;
        //true if within range limits
        return (gapX < RANGE.x && gapX > 0) && (gapY < RANGE.y && gapY > -RANGE.y) ;
    }

    /**
     * checks if the player is with in the range right of the zombie
     * @return true if within range false if out of range
     */
    public boolean inRangeRight() {
        Body a = player;
        //calculate distance between player and zombie
        float gapX = getPosition().x - a.getPosition().x;
        float gapY = getPosition().y - a.getPosition().y;
        //true if within range limits
        return (gapX > -RANGE.x && gapX < 0) && (gapY < RANGE.y && gapY > -RANGE.y) ;
    }

    /**
     * sets the movement state of the zombie, not , move left or move right it stops the zombie
     *
     * <p>right/left/standstill</p>
     * @param e StepListener event
     */
    @Override
    public void preStep(StepEvent e) {
        //set state to move right when player within right range
        if (inRangeRight()) {
            if (state != State.MOVE_RIGHT) {
                state = State.MOVE_RIGHT;
            }
            //set state to move right when player within left range
        } else if (inRangeLeft()) {
            if (state != State.MOVE_LEFT) {
                state = State.MOVE_LEFT;
            }
            // if neither are true and state not already still sets state to stand still and stops zombie
        } else {
            if (state != State.STAND_STILL) {
                state = State.STAND_STILL;
                setAngularVelocity(0);
                setLinearVelocity(new Vec2(0, 0));
            }
        }
        refreshMove();
    }

    /**
     * keeps the zombie moving till state change to stand still
     */
    private void refreshMove() {
        switch (state) {
            case MOVE_LEFT:
                setLinearVelocity(velocityLeft);
                break;
            case MOVE_RIGHT:
                setLinearVelocity(velocityRight);
                break;
            default: // nothing to do
        }
    }

    @Override
    public void postStep(StepEvent e) {

    }
}