package game;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * Options menu class
 * @author      Adam, last Hassan, adam.hassan
 * @version     1.0
 * @since       the version of the package this class was first added to
 */

public class Options {
    private Game game;
    private JPanel mainPanel;
    private JButton quitButton;
    private JButton restartLevelButton;
    private JButton nextLevelButton;
    private JSlider volumeSlider;
    private JButton saveButton;
    private JButton loadButton;

    /**
     * options menu constructor
     * @param game the game object you want to control
     */
    public Options(Game game){
        this.game=game;
        volumeSlider.setValue(50);
        volumeSlider.setMaximum(100);
        volumeSlider.setMinimum(1);

        //restart level button
        restartLevelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.reloadLevel();
                game.setGameFocus();//sets the game frame back into focus
            }
        });

        //next level button

        nextLevelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.goToNextLevel();
                game.setGameFocus();//sets the game frame back into focus
                game.setSkipped(true);

            }
        });

        //save button

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    GameSaveLoad.save(game.getLevel(),"data/save.txt");
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                game.setGameFocus();//sets the game frame back into focus
            }
        });

        //load button
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    game.goToLevel(GameSaveLoad.load(game,"data/save.txt"));
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                game.setGameFocus();//sets the game frame back into focus
            }
        });

        //quit button
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.deleteSave();
                System.exit(0);
                game.setGameFocus();//sets the game frame back into focus

            }
        });

        //volume slider
        volumeSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                game.getLevel().setGameMusicVolume(volumeSlider.getValue());
                game.setGameFocus();//sets the game frame back into focus
            }
        });
    }

    //getter for main panel

    /**
     * getter for the menu
     * @return returns the menu panel
     */
    public JPanel getMainPanel(){
        return mainPanel;
    }

    /**
     * getter for game
     * @return returns the game
     */
    public Game getGame(){
        return game;
    }
}
