package game;


import city.cs.engine.Body;
import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Level3  extends GameLevel implements ActionListener {
    private final Player player;
    private Zombie zombie1;
    private Zombie zombie2;
    private Coin coin1;
    private Coin coin2;
    private Coin coin3;
    private Coin coin4;
    private Crate crate1;

    private int time;
    private Timer timer;


    public Level3(Game game) {
        super(game);

        //timer

        timer = new Timer(1000,this);
        timer.start();
        time=0;



        // make the ground
        //Shape groundShape = new BoxShape(1280f, 0.5f);
        Body ground = new Lava(this);
        ground.setPosition(new Vec2(0, -18f));




        // -----------------------------------CHARACTERS-----------------------------------

        //add player
        player = new Player(this);
        player.setPosition(new Vec2(-31, -8));
        PlayerCollision playercollision = new PlayerCollision(player,this);
        player.addCollisionListener(playercollision);

        zombie1 = new Zombie(this,player);
        zombie1.setPosition(new Vec2(-16,-1));
        ZombieDamage zombieDamage = new ZombieDamage(zombie1);
        zombie1.addCollisionListener(zombieDamage);

        zombie2 = new Zombie(this,player);
        zombie2.setPosition(new Vec2(26,-10));
        ZombieDamage zombieDamage2 = new ZombieDamage(zombie2);
        zombie2.addCollisionListener(zombieDamage2);







        // --------------------------------WALLS AND PLATFORMS--------------------------------

        Shape platShapeLong = new BoxShape(12f,0.5f);
        Shape platShapeSmall= new BoxShape(4f,0.5f);
        Shape platShapeNormal = new BoxShape(6f,0.5f);
        Shape wallShort = new BoxShape(0.5f,1);

        Body platform1= new StaticBody(this,platShapeSmall);
        platform1.setPosition(new Vec2(-28,-10));
        Body platform2= new StaticBody(this,platShapeNormal);
        platform2.setPosition(new Vec2(-15,-3));
        Body platform3= new StaticBody(this,platShapeLong);
        platform3.setPosition(new Vec2(23,-12));

        Body wall = new StaticBody(this,wallShort);
        wall.setPosition(new Vec2(5,-17));








        // --------------------------------OBJECTS--------------------------------
        coin1 = new Coin(this);
        coin2 = new Coin(this);
        coin3 = new Coin(this);
        coin4 = new Coin(this);

        coin1.setPosition(new Vec2(-25,-8.5f));
        coin2.setPosition(new Vec2(-18,-1.5f));
        coin3.setPosition(new Vec2(8,-6f));
        coin4.setPosition(new Vec2(18,-10.5f));


        crate1 = new Crate(this);
        crate1.setPosition(new Vec2(-12,-1));

        Portal portal = new Portal(this);
        portal.setPosition(new Vec2(29,-9.1f));

    }
    //player getter
    public Player getPlayer() {
        return player;
    }

    //get Crate pos
    public Vec2 getCrate1Pos() {
        return crate1.getPosition();
    }


    //set Crate pos
    public void setCrate1Pos(Vec2 pos){
        crate1.setPosition(pos);
    }

    @Override
    public Vec2 getZombiePosition(Zombie zombie) {
        return zombie.getPosition();
    }

    @Override
    public Zombie getZombie1() {
        return zombie1;
    }

    @Override
    public Zombie getZombie2() {
        return zombie2;
    }



    @Override
    public boolean isComplete() {
        if (getPlayer().getCoins() == 4)
            return true;
        else return false;
    }

    //action listener for timer
    @Override
    public void actionPerformed(ActionEvent e){
        time++;
    }

    public int getTime(){
        return time;
    }

    public void setTime(int levelTime){
        this.time = levelTime;
    }

    //stop timer
    public void stopTimer(){
        timer.stop();
    }

    @Override
    public String getLevelName() {
        return "level3";
    }

    public void destroyCoins(int n){
        switch (n){
            case 1:
                coin1.destroy();
                break;
            case 2:
                coin1.destroy();
                coin2.destroy();
                break;
            case 3:
                coin1.destroy();
                coin2.destroy();
                coin3.destroy();
                break;
            case 4:
                coin1.destroy();
                coin2.destroy();
                coin3.destroy();
                coin4.destroy();

                break;
            default:
        }
    }

    @Override
    public void destroyZombies(int n) {
        switch (n) {
            case 1:
                zombie1.destroy();
                break;

            default:
        }
    }
}